﻿public enum BBCursorState {
	Add,
	Update,
	Remove
};
