﻿public partial class TouchReceiver
{
    public enum GestureState
    {
        None,
        Drag,
        Transform
    }
}
