namespace UnityEditor.TestTools.TestRunner.Api
{
    public enum RunState
    {
        NotRunnable,
        Runnable,
        Explicit,
        Skipped,
        Ignored,
    }
}
